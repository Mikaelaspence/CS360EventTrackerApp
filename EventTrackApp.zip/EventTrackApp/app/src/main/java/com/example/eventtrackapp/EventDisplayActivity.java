package com.example.eventtrackapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EventDisplayActivity extends AppCompatActivity {

    // UI elements
    private GridView gridView;
    private Button addEventButton;

    // Database helper instance
    private DatabaseHelper databaseHelper;

    // List to store event data
    private ArrayList<String> eventList;

    // Adapter to display events in the GridView
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        // Initialize UI elements
        gridView = findViewById(R.id.event_grid);
        addEventButton = findViewById(R.id.add_event_button);

        // Initialize database helper and event list
        databaseHelper = new DatabaseHelper(this);
        eventList = new ArrayList<>();

        // Load existing event data from the database
        loadEventData();

        // Set up the adapter to display events in the GridView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        gridView.setAdapter(adapter);

        // Set up listener for the "Add Event" button
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the dialog to add a new event
                showEventDialog(null, -1);
            }
        });

        // Set up listener for item clicks in the GridView (for updating/deleting events)
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            // Show the dialog to edit the selected event
            showEventDialog(eventList.get(position), position);
        });
    }

    // Load all events from the database and refresh the event list
    private void loadEventData() {
        eventList.clear();  // Clear the current list
        eventList.addAll(databaseHelper.getAllEvents());  // Add all events from the database
        if (adapter != null) {
            adapter.notifyDataSetChanged();  // Notify the adapter that the data has changed
        }
    }

    // Show a dialog to add a new event or edit an existing event
    private void showEventDialog(String eventData, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(eventData == null ? "Add Event" : "Edit Event");  // Set dialog title

        // Inflate the dialog layout and get input fields
        View viewInflated = getLayoutInflater().inflate(R.layout.dialog_add_event, null);
        EditText inputName = viewInflated.findViewById(R.id.input_event_name);
        EditText inputDate = viewInflated.findViewById(R.id.input_event_date);

        // If editing an event, pre-fill the input fields with the existing data
        int eventId = -1;
        if (eventData != null) {
            String[] parts = eventData.split(" - ");  // Assume the format is "eventName - eventDate"
            inputName.setText(parts[0]);
            inputDate.setText(parts[1]);

            // Get the actual event ID from the database using the position
            eventId = databaseHelper.getEventIdByPosition(position);
        }

        builder.setView(viewInflated);  // Set the custom view in the dialog

        final int finalEventId = eventId;  // Capture eventId in a final variable for use in the dialog buttons

        // Set up the "Add" or "Update" button in the dialog
        builder.setPositiveButton(eventData == null ? "Add" : "Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String eventName = inputName.getText().toString();
                String eventDate = inputDate.getText().toString();

                if (eventData == null) {
                    // Add a new event to the database
                    if (databaseHelper.addEvent(eventName, eventDate)) {
                        Toast.makeText(EventDisplayActivity.this, "Event added", Toast.LENGTH_SHORT).show();

                        // Show SMS Notification Activity after adding an event
                        Intent intent = new Intent(EventDisplayActivity.this, SMSNotificationsActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(EventDisplayActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Update the existing event in the database
                    if (databaseHelper.updateEvent(finalEventId, eventName, eventDate)) {
                        Toast.makeText(EventDisplayActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(EventDisplayActivity.this, "Failed to update event", Toast.LENGTH_SHORT).show();
                    }
                }
                loadEventData();  // Refresh the event list after adding/updating
            }
        });

        // Set up the "Cancel" or "Delete" button in the dialog
        builder.setNegativeButton(eventData == null ? "Cancel" : "Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (eventData != null) {
                    // Delete the event from the database
                    if (databaseHelper.deleteEvent(finalEventId)) {
                        Toast.makeText(EventDisplayActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                        loadEventData();  // Refresh the event list after deletion
                    } else {
                        Toast.makeText(EventDisplayActivity.this, "Failed to delete event", Toast.LENGTH_SHORT).show();
                    }
                }
                dialog.dismiss();  // Close the dialog
            }
        });

        builder.show();  // Display the dialog
    }
}
